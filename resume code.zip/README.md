
  # Add CC Feature

  This is a code bundle for Add CC Feature. The original project is available at https://www.figma.com/design/Yggm50l3R3T0AielgjSvQb/Add-CC-Feature.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  