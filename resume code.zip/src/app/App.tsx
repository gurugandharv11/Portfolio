import { useState } from 'react';
import { 
  Github, 
  Linkedin, 
  Mail, 
  Download, 
  ExternalLink, 
  FileCode2, 
  Brain, 
  Award, 
  Target, 
  TrendingUp, 
  Sparkles,
  Send,
  ChevronDown,
  Calendar
} from 'lucide-react';

export default function App() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission - would connect to backend in production
    console.log('Form submitted:', formData);
    alert('Thanks for reaching out! This is a demo form.');
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-md z-50 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="font-semibold" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Gandharv
            </div>
            <div className="hidden md:flex gap-8">
              <a href="#about" className="text-gray-600 hover:text-[#4F46E5] transition-colors">About</a>
              <a href="#skills" className="text-gray-600 hover:text-[#4F46E5] transition-colors">Skills</a>
              <a href="#projects" className="text-gray-600 hover:text-[#4F46E5] transition-colors">Projects</a>
              <a href="#experience" className="text-gray-600 hover:text-[#4F46E5] transition-colors">Experience</a>
              <a href="#contact" className="text-gray-600 hover:text-[#4F46E5] transition-colors">Contact</a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-4xl">
            <div className="inline-block px-4 py-2 bg-indigo-50 rounded-full mb-6">
              <span className="text-[#4F46E5]" style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                Available for Internships
              </span>
            </div>
            <h1 className="mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
              <span className="block text-[#0F172A]">Gandharv</span>
            </h1>
            <h2 className="text-[#4F46E5] mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Software Developer | DSA Enthusiast | Full-Stack Engineer
            </h2>
            <p className="text-gray-600 max-w-2xl mb-8">
              Computer Science student with strong DSA foundations and hands-on experience building scalable web and AI-based systems.
            </p>
            <div className="flex flex-wrap gap-4">
              <a 
                href="#projects" 
                className="inline-flex items-center gap-2 bg-[#4F46E5] text-white px-8 py-3 rounded-lg hover:bg-[#4338CA] transition-colors"
              >
                View Projects
                <ChevronDown className="w-4 h-4" />
              </a>
              <button className="inline-flex items-center gap-2 border-2 border-[#0F172A] text-[#0F172A] px-8 py-3 rounded-lg hover:bg-[#0F172A] hover:text-white transition-colors">
                <Download className="w-4 h-4" />
                Download Resume
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="py-12 px-6 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-[#4F46E5] mb-2" style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                250+
              </div>
              <div className="text-gray-600">LeetCode Problems</div>
            </div>
            <div className="text-center">
              <div className="text-[#4F46E5] mb-2" style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                8.69
              </div>
              <div className="text-gray-600">CGPA</div>
            </div>
            <div className="text-center">
              <div className="text-[#4F46E5] mb-2" style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                95%
              </div>
              <div className="text-gray-600">Recognition Accuracy</div>
            </div>
            <div className="text-center">
              <div className="text-[#4F46E5] mb-2" style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                25%
              </div>
              <div className="text-gray-600">Performance Gain</div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
                About Me
              </h2>
              <p className="text-gray-600 mb-6">
                I'm a B.Tech Computer Science Engineering student at Galgotias University (2023–2027) with a strong focus on Data Structures & Algorithms and Full-Stack Development. With a CGPA of 8.69 and 250+ LeetCode problems solved, I bring a problem-solving mindset to every project I build.
              </p>
              <p className="text-gray-600 mb-6">
                My expertise spans Java, React, Node.js, and core CS fundamentals like OOPS, DBMS, and OS. I've developed production-ready applications including an Amazon Clone with performance optimizations and an AI-powered Face Attendance System with 95% accuracy.
              </p>
              <div className="flex gap-4">
                <div className="flex items-center gap-2 text-gray-700">
                  <Brain className="w-5 h-5 text-[#4F46E5]" />
                  <span>Strong DSA Foundations</span>
                </div>
                <div className="flex items-center gap-2 text-gray-700">
                  <FileCode2 className="w-5 h-5 text-[#4F46E5]" />
                  <span>Clean Code Practices</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="rounded-2xl overflow-hidden shadow-xl">
                <img 
                  src="https://images.unsplash.com/photo-1581374820531-029275791beb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBkZXZlbG9wZXIlMjB3b3Jrc3BhY2V8ZW58MXx8fHwxNzY2NDk5Mzc4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral" 
                  alt="Developer workspace"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 bg-[#4F46E5] text-white p-6 rounded-xl shadow-xl">
                <div className="text-center">
                  <div style={{ fontFamily: 'JetBrains Mono, monospace' }}>2023 - 2027</div>
                  <div className="text-sm mt-1">B.Tech CSE</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 px-6 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Technical Skills
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Proficient in modern technologies and industry best practices
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Programming */}
            <div className="bg-white p-6 rounded-xl shadow-sm hover:shadow-lg transition-shadow border border-gray-100">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-indigo-50 rounded-lg flex items-center justify-center">
                  <FileCode2 className="w-6 h-6 text-[#4F46E5]" />
                </div>
                <h3 style={{ fontFamily: 'Poppins, sans-serif' }}>Programming</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {['Java', 'Python', 'JavaScript', 'C/C++'].map(skill => (
                  <span key={skill} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full">
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            {/* Web Development */}
            <div className="bg-white p-6 rounded-xl shadow-sm hover:shadow-lg transition-shadow border border-gray-100">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-indigo-50 rounded-lg flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-[#4F46E5]" />
                </div>
                <h3 style={{ fontFamily: 'Poppins, sans-serif' }}>Web Development</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {['React', 'Node.js', 'Express', 'MongoDB', 'SQL'].map(skill => (
                  <span key={skill} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full">
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            {/* Core CS */}
            <div className="bg-white p-6 rounded-xl shadow-sm hover:shadow-lg transition-shadow border border-gray-100">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-indigo-50 rounded-lg flex items-center justify-center">
                  <Brain className="w-6 h-6 text-[#4F46E5]" />
                </div>
                <h3 style={{ fontFamily: 'Poppins, sans-serif' }}>Core CS</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {['DSA', 'OOPS', 'DBMS', 'OS'].map(skill => (
                  <span key={skill} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full">
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            {/* Tools */}
            <div className="bg-white p-6 rounded-xl shadow-sm hover:shadow-lg transition-shadow border border-gray-100">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-indigo-50 rounded-lg flex items-center justify-center">
                  <Target className="w-6 h-6 text-[#4F46E5]" />
                </div>
                <h3 style={{ fontFamily: 'Poppins, sans-serif' }}>Tools</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {['Git', 'GitHub', 'VS Code', 'Postman', 'MySQL'].map(skill => (
                  <span key={skill} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full">
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            {/* Practices */}
            <div className="bg-white p-6 rounded-xl shadow-sm hover:shadow-lg transition-shadow border border-gray-100">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-indigo-50 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-[#4F46E5]" />
                </div>
                <h3 style={{ fontFamily: 'Poppins, sans-serif' }}>Practices</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {['Clean Code', 'Debugging', 'Optimization'].map(skill => (
                  <span key={skill} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Featured Projects
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Real-world applications showcasing full-stack development and AI integration
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Amazon Clone */}
            <div className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow border border-gray-100">
              <div className="h-48 bg-gradient-to-br from-[#4F46E5] to-[#7C3AED] flex items-center justify-center">
                <div className="text-white text-center">
                  <div style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                    E-Commerce Platform
                  </div>
                </div>
              </div>
              <div className="p-6">
                <h3 className="mb-3" style={{ fontFamily: 'Poppins, sans-serif' }}>
                  Amazon Clone Website
                </h3>
                <p className="text-gray-600 mb-4">
                  Full-featured e-commerce platform with user authentication, product catalog, shopping cart, and checkout functionality. Implemented REST APIs and achieved 25% faster load times through optimization.
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  <span className="px-3 py-1 bg-indigo-50 text-[#4F46E5] rounded-full">React</span>
                  <span className="px-3 py-1 bg-indigo-50 text-[#4F46E5] rounded-full">Node.js</span>
                  <span className="px-3 py-1 bg-indigo-50 text-[#4F46E5] rounded-full">REST API</span>
                  <span className="px-3 py-1 bg-indigo-50 text-[#4F46E5] rounded-full">MongoDB</span>
                </div>
                <div className="flex items-center gap-2 text-gray-700 mb-4">
                  <TrendingUp className="w-4 h-4 text-green-600" />
                  <span>25% Performance Improvement</span>
                </div>
                <div className="flex gap-3">
                  <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                    <Github className="w-4 h-4" />
                    GitHub
                  </button>
                  <button className="flex items-center gap-2 px-4 py-2 bg-[#4F46E5] text-white rounded-lg hover:bg-[#4338CA] transition-colors">
                    <ExternalLink className="w-4 h-4" />
                    Live Demo
                  </button>
                </div>
              </div>
            </div>

            {/* Face Attendance System */}
            <div className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow border border-gray-100">
              <div className="h-48 bg-gradient-to-br from-[#EC4899] to-[#8B5CF6] flex items-center justify-center">
                <div className="text-white text-center">
                  <div style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                    AI-Powered System
                  </div>
                </div>
              </div>
              <div className="p-6">
                <h3 className="mb-3" style={{ fontFamily: 'Poppins, sans-serif' }}>
                  Face Attendance System
                </h3>
                <p className="text-gray-600 mb-4">
                  Automated attendance tracking system using facial recognition. Built with Flask, OpenCV, and MySQL with modular architecture for scalability. Achieves 95% recognition accuracy in real-world conditions.
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  <span className="px-3 py-1 bg-indigo-50 text-[#4F46E5] rounded-full">Flask</span>
                  <span className="px-3 py-1 bg-indigo-50 text-[#4F46E5] rounded-full">OpenCV</span>
                  <span className="px-3 py-1 bg-indigo-50 text-[#4F46E5] rounded-full">MySQL</span>
                  <span className="px-3 py-1 bg-indigo-50 text-[#4F46E5] rounded-full">Python</span>
                </div>
                <div className="flex items-center gap-2 text-gray-700 mb-4">
                  <Award className="w-4 h-4 text-green-600" />
                  <span>95% Recognition Accuracy</span>
                </div>
                <div className="flex gap-3">
                  <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                    <Github className="w-4 h-4" />
                    GitHub
                  </button>
                  <button className="flex items-center gap-2 px-4 py-2 bg-[#4F46E5] text-white rounded-lg hover:bg-[#4338CA] transition-colors">
                    <ExternalLink className="w-4 h-4" />
                    Live Demo
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Experience Timeline */}
      <section id="experience" className="py-20 px-6 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Learning & Experience
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Continuous learning through industry certifications and training programs
            </p>
          </div>

          <div className="max-w-3xl mx-auto">
            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-0 md:left-1/2 top-0 bottom-0 w-0.5 bg-gray-200"></div>

              {/* Timeline items */}
              {[
                { title: 'Infosys Eduskills', description: 'Advanced Full-Stack Development Training', year: '2024' },
                { title: 'Oracle Academy', description: 'Database & Java Programming', year: '2024' },
                { title: 'Google for Developers', description: 'Web Development & Best Practices', year: '2024' },
                { title: 'Guvi', description: 'DSA & Problem Solving', year: '2023' },
                { title: 'E-Cell IIT Roorkee', description: 'Entrepreneurship & Innovation', year: '2023' }
              ].map((item, index) => (
                <div key={index} className={`relative mb-12 ${index % 2 === 0 ? 'md:pr-1/2 md:text-right' : 'md:pl-1/2 md:ml-auto md:text-left'}`}>
                  {/* Timeline dot */}
                  <div className="absolute left-0 md:left-1/2 w-4 h-4 bg-[#4F46E5] rounded-full -ml-[7px] md:-ml-[7px] ring-4 ring-white"></div>
                  
                  <div className={`ml-8 md:ml-0 ${index % 2 === 0 ? 'md:mr-12' : 'md:ml-12'}`}>
                    <div className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-gray-100">
                      <div className="flex items-center gap-2 mb-2 text-[#4F46E5]">
                        <Calendar className="w-4 h-4" />
                        <span style={{ fontFamily: 'JetBrains Mono, monospace' }}>{item.year}</span>
                      </div>
                      <h4 style={{ fontFamily: 'Poppins, sans-serif' }}>{item.title}</h4>
                      <p className="text-gray-600 mt-2">{item.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Achievements & Stats */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Achievements & Impact
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Quantifiable results and technical milestones
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-gradient-to-br from-[#4F46E5] to-[#7C3AED] p-8 rounded-xl text-white text-center shadow-xl">
              <div className="mb-3" style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                250+
              </div>
              <div className="opacity-90">LeetCode Problems</div>
              <div className="mt-4 pt-4 border-t border-white/20">
                <div className="flex items-center justify-center gap-2 text-sm">
                  <Brain className="w-4 h-4" />
                  <span>Strong DSA</span>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-[#EC4899] to-[#F97316] p-8 rounded-xl text-white text-center shadow-xl">
              <div className="mb-3" style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                8.69
              </div>
              <div className="opacity-90">CGPA</div>
              <div className="mt-4 pt-4 border-t border-white/20">
                <div className="flex items-center justify-center gap-2 text-sm">
                  <Award className="w-4 h-4" />
                  <span>Academic Excellence</span>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-[#10B981] to-[#059669] p-8 rounded-xl text-white text-center shadow-xl">
              <div className="mb-3" style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                95%
              </div>
              <div className="opacity-90">Face Recognition Accuracy</div>
              <div className="mt-4 pt-4 border-t border-white/20">
                <div className="flex items-center justify-center gap-2 text-sm">
                  <Target className="w-4 h-4" />
                  <span>AI Precision</span>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-[#F59E0B] to-[#D97706] p-8 rounded-xl text-white text-center shadow-xl">
              <div className="mb-3" style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                25%
              </div>
              <div className="opacity-90">Performance Improvement</div>
              <div className="mt-4 pt-4 border-t border-white/20">
                <div className="flex items-center justify-center gap-2 text-sm">
                  <TrendingUp className="w-4 h-4" />
                  <span>Optimization</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-6 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Get In Touch
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Open to internship opportunities and collaborative projects
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
            {/* Contact Info */}
            <div>
              <h3 className="mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
                Let's Connect
              </h3>
              <div className="space-y-4">
                <a 
                  href="mailto:gandharv@example.com" 
                  className="flex items-center gap-4 p-4 bg-white rounded-lg hover:shadow-md transition-shadow border border-gray-100"
                >
                  <div className="w-12 h-12 bg-indigo-50 rounded-lg flex items-center justify-center">
                    <Mail className="w-6 h-6 text-[#4F46E5]" />
                  </div>
                  <div>
                    <div className="text-gray-600 text-sm">Email</div>
                    <div className="text-[#0F172A]">gandharv@example.com</div>
                  </div>
                </a>

                <a 
                  href="https://linkedin.com/in/gandharv" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 p-4 bg-white rounded-lg hover:shadow-md transition-shadow border border-gray-100"
                >
                  <div className="w-12 h-12 bg-indigo-50 rounded-lg flex items-center justify-center">
                    <Linkedin className="w-6 h-6 text-[#4F46E5]" />
                  </div>
                  <div>
                    <div className="text-gray-600 text-sm">LinkedIn</div>
                    <div className="text-[#0F172A]">linkedin.com/in/gandharv</div>
                  </div>
                </a>

                <a 
                  href="https://github.com/gandharv" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 p-4 bg-white rounded-lg hover:shadow-md transition-shadow border border-gray-100"
                >
                  <div className="w-12 h-12 bg-indigo-50 rounded-lg flex items-center justify-center">
                    <Github className="w-6 h-6 text-[#4F46E5]" />
                  </div>
                  <div>
                    <div className="text-gray-600 text-sm">GitHub</div>
                    <div className="text-[#0F172A]">github.com/gandharv</div>
                  </div>
                </a>
              </div>
            </div>

            {/* Contact Form */}
            <div>
              <form onSubmit={handleSubmit} className="bg-white p-8 rounded-xl shadow-sm border border-gray-100">
                <div className="mb-4">
                  <label htmlFor="name" className="block text-gray-700 mb-2">
                    Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#4F46E5] focus:border-transparent"
                    required
                  />
                </div>

                <div className="mb-4">
                  <label htmlFor="email" className="block text-gray-700 mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#4F46E5] focus:border-transparent"
                    required
                  />
                </div>

                <div className="mb-6">
                  <label htmlFor="message" className="block text-gray-700 mb-2">
                    Message
                  </label>
                  <textarea
                    id="message"
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    rows={4}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#4F46E5] focus:border-transparent resize-none"
                    required
                  />
                </div>

                <button 
                  type="submit"
                  className="w-full bg-[#4F46E5] text-white py-3 rounded-lg hover:bg-[#4338CA] transition-colors flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#0F172A] text-white py-12 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div>
              <div className="mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
                Gandharv
              </div>
              <div className="text-gray-400">
                Software Developer | DSA Enthusiast | Full-Stack Engineer
              </div>
            </div>
            <div className="flex gap-6">
              <a href="https://github.com/gandharv" target="_blank" rel="noopener noreferrer" className="hover:text-[#4F46E5] transition-colors">
                <Github className="w-6 h-6" />
              </a>
              <a href="https://linkedin.com/in/gandharv" target="_blank" rel="noopener noreferrer" className="hover:text-[#4F46E5] transition-colors">
                <Linkedin className="w-6 h-6" />
              </a>
              <a href="mailto:gandharv@example.com" className="hover:text-[#4F46E5] transition-colors">
                <Mail className="w-6 h-6" />
              </a>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-800 text-center text-gray-400">
            <p>© 2024 Gandharv. Built with React & Tailwind CSS.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
